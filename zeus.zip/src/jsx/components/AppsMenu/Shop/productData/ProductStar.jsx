export const starOne = (
   <ul className="star-rating">
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
   </ul>
);

export const starTwo = (
   <ul className="star-rating">
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
   </ul>
);

export const starThree = (
   <ul className="star-rating">
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
   </ul>
);

export const starFour = (
   <ul className="star-rating">
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa-solid fa-star-half-stroke" />
      </li>
   </ul>
);

export const starFive = (
   <ul className="star-rating">
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
      <li className="me-sm-1">
         <i className="fa fa-star" />
      </li>
   </ul>
);
