import React from "react";
import { Link } from "react-router-dom";

import Error from '../../images/error.svg';

const Error404 = () => {
   return (
      <div className="fix-wrapper bg-white">
         <div className="container">
            <div className="row  align-items-center">
               <div className="col-lg-6 col-sm-6">
                  <div className="form-input-content  error-page">
                     <h1 className="error-text text-primary">404</h1>
                     <h4>The page you were looking for is not found!</h4>
                     <p>You may have mistyped the address or the page may have moved.</p>
                     <Link to={"/dashboard"} className="btn btn-primary">Back to Home</Link>
                  </div>
               </div>
               <div className="col-lg-6 col-sm-6">
                  <img className="w-100" src={Error} alt="" />
               </div>
            </div>
         </div>
      </div>
   );
};

export default Error404;
